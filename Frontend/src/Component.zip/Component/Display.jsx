import React, { useState, useEffect } from "react";
import axios from "axios";

const Display = () => {
  const [users, setUsers] = useState([]);
  const [editingUserId, setEditingUserId] = useState(null);
  const [updatedName, setUpdatedName] = useState("");

  // fetch the data
  useEffect(() => {
    const fetchUsers = async () => {
      const response = await axios.get("http://127.0.0.1:5000/persons");
      setUsers(response.data);
      
    };
    fetchUsers();
    
  }, []);

  //The Delete button

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/persons/${id}`);
      setUsers(users.filter((user) => user.id !== id));
    } catch (error) {
      console.log(error);
    }
  };


  const handleUpdate = async (id) => {
    try {
      const payload = { name: updatedName };
      const response = await axios.patch(
        `http://localhost:5000/persons/${id}`,
        payload
      );
      const updatedUser = response.data;
      setUsers(
        users.map((user) => (user.id === updatedUser.id ? updatedUser : user))
      );
      setEditingUserId(null);
      setUpdatedName("");
    } catch (error) {
      console.log(error);
    }
  };


  return (
    <div className="container">
      <div className="row">
        {users.map((user) => (
          <div key={user.id} className="col-sm-6 col-md-4 col-lg-3">
            <div className="card mb-4">
              <div className="card-body">
                {editingUserId === user.id ? (
                  <div>
                    <div className="form-group">
                      <label>Name:</label>
                      <input
                        type="text"
                        className="form-control"
                        value={updatedName}
                        onChange={(event) => setUpdatedName(event.target.value)}
                      />
                    </div>
                    <button
                      className="btn btn-primary w-100 mt-2"
                      onClick={() => handleUpdate(user.id)}
                    >
                      Update
                    </button>
                  </div>
                ) : (
                  <div>
                    <h5 className="card-title">{user.name}</h5>
                    <p className="card-text">Email: {user.email}</p>
                    <p className="card-text">Gender: {user.gender}</p>
                    <p className="card-text">Age: {user.age}</p>
                    <button
                      className="btn btn-danger mr-2 w-100"
                      onClick={() => handleDelete(user.id)}
                    >
                      Delete
                    </button>
                    <button
                      className="btn btn-primary w-100 mt-2"
                      onClick={() => {
                        setEditingUserId(user.id);
                        setUpdatedName(user.name);
                      }}
                    >
                      Edit
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Display;